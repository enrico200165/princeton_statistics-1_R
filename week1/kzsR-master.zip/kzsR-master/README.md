kzsR
====

Zsolt's R practice files